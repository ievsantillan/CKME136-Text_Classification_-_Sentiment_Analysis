
# CKME136 - Text Classification & Sentiment Analysis - isantillan

***

#### 1.0 Introduction

#### 2.0 Background

#### 3.0 Data Description

#### 4.0 Methodology
- **4.1 Data Collection & Processing**
 - 4.1.1 Importing the required libraries
 - 4.1.2 Creating the Twitter App & registering for a Twitter API
 - 4.1.3 Creating a pandas DataFrame
- **4.2 Exploratory Data Analysis**
 - 4.2.1 Popularity and averages
 - 4.2.2 Time Series - Length, Likes & Retweets
 - 4.2.3 Pie chart - Tweet Sources
 - 4.2.4 WordCloud
- **4.3 Classification & Sentiment Analysis**
 - 4.3.1 Classifying the tweets
 - 4.3.2 Analyzing the results
 - 4.3.3 BagOfWords; CountVectorizer

#### 5.0 Future Work & Next steps
#### 6.0 References


***

## 1.0 Introduction

For the CKME136 Capstone Project, we were provided with the following themes to work with:
- Text Classication and Sentiment Analysis
- Classication and Regression (non-textual dataset)
- Predictive Analytics (Pattern mining, Time-series, Causality, etc.)
- Recommender systems (Collaborative; Content-based ltering, etc.)
- Anomaly Detection (outliers detection)
- Data Mining and knowledge discovery

For this project, we'll be focusing on `Text Classication & Sentiment Analysis`

## 2.0 Background

**Sentiment Analysis** also known as *Opinion Mining* is the process of extracting and understanding human feelings from data. Sentiment analysis is widely applied to reviews and social media for a variety of applications, ranging from marketing to customer service.

Traditionally pyschologists would formulate a hypothesis, then to test it they would find a subset of people that would fit their cateogry, bring them into the lab and ask them to do some tasks while recording the results. But with data freely available, we as Data Scientists can do the same thing with the best psychology tool out there, twitter! 
![image.png](attachment:image.png)

Twitter is a treasure trove of sentiment. People around the world output thousands of reactions and opinions on every topic under the sun, every second of every day. It's like one giant psychological database that is constantly being updated and we can use it ot analyze millions of text snippets, in seconds, with the power of machine learning. 

## 3.0 Data Description

![image.png](attachment:image.png)

In this project, we'll use *Tweepy* to scrape **Stantec's** twitter account and use the Natural Language Libraries *TextBlob* and *VADER* to analyze the tweet's sentiment.

Please see here for the full list of the 
[file stucture of tweepy status object json](https://gist.github.com/dev-techmoe/ef676cdd03ac47ac503e856282077bf2#file-structure-of-tweepy-status-object-json).

For this project, we'll be using the following features :

|Name|Description|
|------|------|
|ID|Twitter User ID|
|source|tweet source|
|created_at|Date created |
|text|tweet text |
|favorite_count|Favorite count|
|retweet_count|Retweet count|

## 4.0 Methodology

**Tweepy** is an easy-to-use Python library for accessing the Twitter API.

**TextBlob** is a Python (2 and 3) library for processing textual data which is built on the NTLK package. It provides a simple API for diving into common natural language processing (NLP) tasks such as part-of-speech tagging, noun phrase extraction, sentiment analysis, classification, translation, and more

**VADER-Sentiment-Analysis** 
VADER (Valence Aware Dictionary and sEntiment Reasoner) is a lexicon and rule-based sentiment analysis tool that is specifically attuned to sentiments expressed in social media.

### How does Sentiment Analysis work?

![image.png](attachment:image.png)

![image.png](attachment:image.png)

When we receive some input text, a tweet, we'll first want to split it up into several words or sentences. This process is called *Tokenization* because we're creating small tokens from big text. 

**Tokenization** is the process of breaking a stream of textual content up into words, terms, symbols, or some other meaningful elements called tokens.

**Stemming** is the removal of "variable" parts of words, leaving only the stem. Treating words with the same stem as the same for analysis:
 - likes > like
 - liked > like
 - liking > like
 - like > like
 
**Lemmatization** is similar to stemming, but leaves the real word, not the stem:
 - creativity > create

### 4.1 Data Collection & Processing

#### 4.1.1 Importing the required libraries

- data collection
    - **tweepy** - An easy-to-use Python library for accessing the Twitter API.
- data manipulation
    - **numpy** - the fundamental package for scientific computing with Python
    - **pandas** - for using data structures and data analysis tools
    - **re** - This module provides regular expression matching operations similar to those found in Perl. Both patterns and strings to be searched can be Unicode strings as well as 8-bit strings.
- text transformation
    - **CountVectorizer** - converts a collection of text documents to a matrix of token counts
- sentiment analysis
    - **textblob** - is a Python (2 and 3) library for processing textual data. It provides a simple API for diving into common natural language processing (NLP) tasks such as part-of-speech tagging, noun phrase extraction, sentiment analysis, classification, translation
    - **SentimentIntensityAnalyzer** - VADER (Valence Aware Dictionary and sEntiment Reasoner) is a lexicon and rule-based sentiment analysis tool that is specifically attuned to sentiments expressed in social media. 
- visualization
    - **wordcloud** - A little word cloud generator in Python
    - **ipython.display** - Public API for display tools in IPython
    - **matplotlib** - a Python 2D plotting library which produces publication quality figures in a variety of hardcopy formats and interactive environments across platforms
    - **seaborn** - a data visualization library based on matplotlib. It provides a high-level interface for drawing attractive and informative statistical graphics.




```python
# data collection
import tweepy

# data manipulation
import pandas as pd
import numpy as np
import re

# text transformation
from sklearn.feature_extraction.text import CountVectorizer

# sentiment analysis
from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# visualization
from wordcloud import WordCloud
from IPython.display import display
import matplotlib.pyplot as plt
import seaborn as sns

%matplotlib inline
```

#### 4.1.2 Creating the Twitter App & registering for a Twitter API

![image.png](attachment:image.png)

An **API** or an **Application Programing Interface** is a gateway that lets you access some servers' internal functionality. In our case, Twitter. Thus, we will be able to read and write tweets right from our app using Twitter's API. 

![image.png](attachment:image.png)

Let's sign up for it in the browser! 

First we'll want to make sure that we have a Twitter account set up with a verified phone number attached to it. Once we have that, we can create our first Twitter app. We'll select the 'Create New App' button and type in a *name* and a *description* of our app, as well as a website. Once we have all the required information, we can press the 'Create Your Twitter application' button on the bottom and our app is created!

![image.png](attachment:image.png)

We can go to our app and click on the 'Keys and Access Tokens' Tab. We're going to need to use these keys in our script to authenticate or verify our identity with Twitter 

![image.png](attachment:image.png)

![image.png](attachment:image.png)

***

For the purpose of this project, we'll show the required keys here to access twitter:

Let's create the 4 variables that we'll need to authenticate with Twitter, which basically means, login via code. 

- consumer_key
- consumer_secret
- access_token
- access_token_secret

To do that, we'll create a variable called auth for authentication and use the **OAuthhandler** of tweepy. This method takes 2 arguements, the `consumer_key` and the `consumer_secret`.

We'll also need to call the **set_access_token** on the auth variable which takes 2 arguements: the `access_token` and the `access_token_secret`. That's it! We've created our authentication variable; `auth`.


```python
# consumer keys
consumer_key = 'yf2Hy9e0iTF7cyRVJlprHUOhy'
consumer_secret = '0UA45fOO4frij3blmrJTfmgCUsTp56mFjgHzn2WFBrmloYtblM'

# access token keys
access_token = '23886393-OFMXGQQzyNnXujkGXCpqy7dNYXA2yP1xEuHpW0o0S'
access_token_secret = 'u3t9yXa7lTuknxyM47hxA2na7dj4JWfJlS9uxQ6LSSMpv'
```

Now we want to create our main variable from which we'll do all of our Twitter analysis on. We'll call it `api` and assign it a value from the tweepy api method which takes a single authentication argument


```python
# connect to twitter API
def twitter_connect():
    '''
    function to connect to twitter's API
    with the provided consumer and access keys
    '''
    # authentication
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    
    # return api with authentication:
    api = tweepy.API(auth)
    return api
```


```python
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
api = tweepy.API(auth)
```


```python
# create an extractor object
extractor = twitter_connect()

# create a tweet list 
tweets = extractor.user_timeline(screen_name='stantec', count=200) # max is 200
print("Extracted {} tweets.\n".format(len(tweets)))

# print last 5 tweets:
print("5 most recent tweets:\n")
for tweet in tweets[:5]:
    print(tweet.text)
    print()

```

    Extracted 200 tweets.
    
    5 most recent tweets:
    
    ICYMI: “Examine the stability of the creek and the vegetation on the banks, and see what creatures are calling the… https://t.co/thahjxAIcy
    
    ICYMI: The heart of the home also has a vital role in the workplace. Our @BlakeJackson81 explains how effective… https://t.co/HW2lAYIJ3r
    
    Don’t miss the new season of Project Impossible this weekend on HISTORY Canada. Stantec-designed projects are featu… https://t.co/a6X8ls7Fu0
    
    Our #Denver office is excited to sponsor the inaugural @thirstyfestdenver on Saturday. All proceeds from ThirstyFes… https://t.co/j8nxzBkvxQ
    
    Proud to be recognized as an industry leader on @ENRnews Top 150 #Design Firms, a result of our continued growth an… https://t.co/jdwlb0rq4y
    
    

#### 4.1.3 Creating a pandas DataFrame


```python
# create a pandas dataframe
data = pd.DataFrame(data=[tweet.text for tweet in tweets], columns=['Tweets'])

# display the first 10 tweets
display(data.head(10))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tweets</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ICYMI: “Examine the stability of the creek and...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ICYMI: The heart of the home also has a vital ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Don’t miss the new season of Project Impossibl...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Our #Denver office is excited to sponsor the i...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Proud to be recognized as an industry leader o...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>#Workhard &amp;amp; #playhard, dat doen onze young...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Delighted to announce that Tim Williams has jo...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>.@HISTORY is launching a new season of Project...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>It’s amazing when a plan comes together. Our t...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Our #SanFrancisco office is so grateful for th...</td>
    </tr>
  </tbody>
</table>
</div>



```python
# investigating internal methods of the Tweet object
print(dir(tweets[0]))
```

    ['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getstate__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', '_api', '_json', 'author', 'contributors', 'coordinates', 'created_at', 'destroy', 'entities', 'favorite', 'favorite_count', 'favorited', 'geo', 'id', 'id_str', 'in_reply_to_screen_name', 'in_reply_to_status_id', 'in_reply_to_status_id_str', 'in_reply_to_user_id', 'in_reply_to_user_id_str', 'is_quote_status', 'lang', 'parse', 'parse_list', 'place', 'possibly_sensitive', 'retweet', 'retweet_count', 'retweeted', 'retweets', 'source', 'source_url', 'text', 'truncated', 'user']
    


```python
# let's explore the following 
print(tweets[0].id)
print(tweets[0].source)
print(tweets[0].created_at)
print(tweets[0].lang)
print(tweets[0].favorite_count)
print(tweets[0].retweet_count)
print(tweets[0].geo)
print(tweets[0].coordinates)
print(tweets[0].entities)
```

    1023615412418879489
    Hootsuite Inc.
    2018-07-29 17:05:06
    en
    2
    1
    None
    None
    {'hashtags': [], 'symbols': [], 'user_mentions': [], 'urls': [{'url': 'https://t.co/thahjxAIcy', 'expanded_url': 'https://twitter.com/i/web/status/1023615412418879489', 'display_url': 'twitter.com/i/web/status/1…', 'indices': [116, 139]}]}
    


```python
# adding additional information to our DataFrame
data['ID'] = np.array([tweet.id for tweet in tweets])
data['source'] = np.array([tweet.source for tweet in tweets])
data['date'] = np.array([tweet.created_at for tweet in tweets])
data['lang'] = np.array([tweet.lang for tweet in tweets])
data['len'] = np.array([len(tweet.text) for tweet in tweets])
data['likes'] = np.array([tweet.favorite_count for tweet in tweets])
data['rts'] = np.array([tweet.retweet_count for tweet in tweets])

display(data.head(10))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tweets</th>
      <th>ID</th>
      <th>source</th>
      <th>date</th>
      <th>lang</th>
      <th>len</th>
      <th>likes</th>
      <th>rts</th>
      <th>SA_tb</th>
      <th>SA_vd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ICYMI: “Examine the stability of the creek and...</td>
      <td>1023615412418879489</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-29 17:05:06</td>
      <td>en</td>
      <td>139</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ICYMI: The heart of the home also has a vital ...</td>
      <td>1023268125134008321</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-28 18:05:07</td>
      <td>en</td>
      <td>136</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Don’t miss the new season of Project Impossibl...</td>
      <td>1023236913539571713</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-28 16:01:05</td>
      <td>en</td>
      <td>140</td>
      <td>16</td>
      <td>9</td>
      <td>-1</td>
      <td>-1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Our #Denver office is excited to sponsor the i...</td>
      <td>1022859412099289088</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 15:01:02</td>
      <td>en</td>
      <td>140</td>
      <td>10</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Proud to be recognized as an industry leader o...</td>
      <td>1022844196061884416</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 14:00:34</td>
      <td>en</td>
      <td>140</td>
      <td>12</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>#Workhard &amp;amp; #playhard, dat doen onze young...</td>
      <td>1022777542279880704</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 09:35:43</td>
      <td>nl</td>
      <td>128</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Delighted to announce that Tim Williams has jo...</td>
      <td>1022774869002473472</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 09:25:05</td>
      <td>en</td>
      <td>144</td>
      <td>10</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>.@HISTORY is launching a new season of Project...</td>
      <td>1022497090969260032</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 15:01:18</td>
      <td>en</td>
      <td>140</td>
      <td>18</td>
      <td>5</td>
      <td>-1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>It’s amazing when a plan comes together. Our t...</td>
      <td>1022493959522865152</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 14:48:51</td>
      <td>en</td>
      <td>140</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Our #SanFrancisco office is so grateful for th...</td>
      <td>1022485478770135041</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 14:15:09</td>
      <td>en</td>
      <td>127</td>
      <td>8</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


## 4.2 Exploratory Data Analysis

#### 4.2.1 Popularity and averages


```python
# mean tweet length
mean = np.mean(data['len'])

print("The tweet's average length is: {}".format(mean))
```

    The tweet's average length is: 138.335
    


```python
# find the tweet that has the most likes and retweets.

likes_max = np.max(data['likes'])
rt_max = np.max(data['rts'])

likes = data[data.likes == likes_max].index[0]
rt = data[data.rts == rt_max].index[0]

# most likes 
print("The tweet that has the most likes is: \n{}".format(data['Tweets'][likes]))
print("Date & Time: {}".format(data['date'][likes]))
print("Number of likes: {}".format(likes_max))
print("{} characters.\n".format(data['len'][likes]))

# most retweets 
print("The tweet that has the most retweets is: \n{}".format(data['Tweets'][rt]))
print("Date & Time: {}".format(data['date'][rt]))
print("Number of retweets: {}".format(rt_max))
print("{} characters.\n".format(data['len'][rt]))
```

    The tweet that has the most likes is: 
    More than a dozen Stantec volunteers (and a bunch of their helpful children) were thrilled to spend part of their w… https://t.co/d0XEWwt9FJ
    Date & Time: 2018-07-19 22:45:06
    Number of likes: 25
    140 characters.
    
    The tweet that has the most retweets is: 
    Don’t miss the new season of Project Impossible this weekend on HISTORY Canada. Stantec-designed projects are featu… https://t.co/a6X8ls7Fu0
    Date & Time: 2018-07-28 16:01:05
    Number of retweets: 9
    140 characters.
    
    

#### 4.2.2 Time Series - Length, Likes & Retweets


```python
# create a time series for data
tlen = pd.Series(data=data['len'].values, index=data['date'])
tlik = pd.Series(data=data['likes'].values, index=data['date'])
trts = pd.Series(data=data['rts'].values, index=data['date'])
```


```python
# plot lengths along time
tlen.plot(figsize=(16,4), color='r')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d5c22d8550>




![png](output_51_1.png)



```python
# visualizing likes vs retweets
tlik.plot(figsize=(16,4), label="Likes", legend=True)
trts.plot(figsize=(16,4), label="Retweets", legend=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d5bd50bc88>




![png](output_52_1.png)


#### 4.2.3 Pie chart - Tweet sources


```python
# grab all sources
sources = []
for source in data['source']:
    if source not in sources:
        sources.append(source)
        
# print sources list
print("Tweet content sources:")
for source in sources:
    print("- {}".format(source))
```

    Tweet content sources:
    - Hootsuite Inc.
    - Twitter Web Client
    - Twitter for iPhone
    - Hootsuite
    


```python
# create a numpy vector mapped to labels
percent = np.zeros(len(sources))

for source in data['source']:
    for index in range (len(sources)):
        if source == sources[index]:
            percent[index] += 1
            pass
percent /= 100

# pie chart
pie_chart = pd.Series(percent, index=sources, name='sources')
pie_chart.plot.pie(fontsize=11, autopct='%.2f', figsize=(6,6))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d5bd561358>




![png](output_55_1.png)


> *Hootsuite* is a social media management platform. The system’s user interface takes the form of a dashboard, and supports social network integrations for Twitter, Facebook, Instagram, LinkedIn, Google+ and YouTube.

#### 4.2.4 WordCloud

Let's generate a WorldCloud from tweets from the **Stantec** account


```python
def tweet_search(query, limit = 200, language = 'en', remove = []):
    '''
    Function to search for tweets, setting default language,
    and removing stopwords
    '''
    # create a blank variable
    text = ""
    # Iterate through Twitter using Tweepy to find our query in our language, with our defined limit
    # For every tweet that has our query, add it ot our text holder in lower case
    for tweet in tweepy.Cursor(api.search, q = query, lang = language).items(limit):
        text += tweet.text.lower()
        
        # Twitter has lots of links, we need to remove the commons parts of links to clean our data
        # First, create a list of terms that we want ot remove. This contains  https & co, alongside any words in our remove list
        removeWords = ["https", "co", "rt", "join"]
        removeWords += remove
        
    # For each word in our removeWords list, replace it with nothing in our main text 
    for word in removeWords:
        text = text.replace(word, "")
    # return our clean text
    return text
```


```python
stantec_tweets = tweet_search("stantec", remove =["stantec", "stn"])
```


```python
wordcloud = WordCloud(background_color = 'black', width = 1400, height = 450).generate(stantec_tweets)
plt.figure(figsize = (20,10), facecolor = 'k')
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")
plt.tight_layout(pad = 0)
plt.show()
```


![png](output_61_0.png)


#### 4.3.5 Bag of words


```python
# function to clean the tweets
def clean_tweet(tweet):
    '''
    Function to clean the text in a tweet by removing 
    links and special characters with regex.
    '''
    return ' '.join(re.subA-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\/S+)", " ", tweet).split())

# function to classify the tweet's polarity (-1, 0, 1) using t("(@[extBlob
def analyze_sentiment_tb(tweet):
    '''
    Function to classify the polarity of a tweet
    using textblob
    '''
    analysis_tb = TextBlob(clean_tweet(tweet))
    if analysis_tb.sentiment.polarity > 0:
        return 1
    elif analysis_tb.sentiment.polarity == 0:
        return 0
    else:
        return -1

# function to classify the tweet's polarity (-1, 0, 1) using VADER
def analyze_sentiment_vd(tweet):
    '''
    Function to classify the polarity of a tweet using
    VADER (Valence Aware Dictionary and sEntiment Reasoner) 
    '''
    analysis_vd = SentimentIntensityAnalyzer()
    vd = analysis_vd.polarity_scores(clean_tweet(tweet))

    if vd['compound'] > 0:
        return 1
    elif vd['compound'] == 0:
        return 0
    else:
        return -1

```


```python
from sklearn.feature_extraction.text import CountVectorizer

corpus = np.array([clean_tweet(tweet) for tweet in data['Tweets']]).tolist()

vectorizer = CountVectorizer(max_features=100)
print(vectorizer.fit_transform(corpus).todense())
print(vectorizer.vocabulary_)

X_train_counts = vectorizer.fit_transform(corpus)
```

    [[0 0 0 ... 0 0 0]
     [0 0 0 ... 0 0 0]
     [0 0 0 ... 0 0 0]
     ...
     [0 0 0 ... 0 0 0]
     [0 0 0 ... 0 1 1]
     [0 0 0 ... 0 0 0]]
    {'icymi': 39, 'the': 74, 'of': 54, 'and': 4, 'on': 56, 'what': 88, 'are': 5, 'https': 38, 'co': 14, 'home': 35, 'has': 30, 'in': 42, 'workplace': 95, 'our': 57, 'explains': 24, 'how': 37, 'don': 22, 'new': 52, 'project': 61, 'this': 77, 'stantec': 71, 'projects': 62, 'denver': 16, 'office': 55, 'is': 43, 'to': 78, 'from': 29, 'proud': 63, 'be': 8, 'as': 6, 'an': 3, 'leader': 46, 'design': 17, 'amp': 2, 'that': 73, 'for': 28, 'will': 92, 'it': 45, 'when': 89, 'plan': 60, 'team': 72, 'so': 69, 'do': 20, 'have': 31, 'can': 13, 'you': 98, 'if': 40, 'your': 99, 'today': 79, 'blog': 10, 'us': 82, 'about': 1, 'video': 83, 'at': 7, 'he': 32, 'with': 93, 'week': 87, 'rt': 66, 'why': 91, 'building': 12, 'year': 96, 'skate': 68, 'water': 85, 'up': 80, 'where': 90, 'designers': 18, 'we': 86, 'park': 59, 'more': 51, 'their': 75, 'out': 58, 'find': 25, 're': 64, 'like': 48, 'engineering': 23, 'share': 67, 'look': 49, 'conference': 15, 'heading': 33, 'bmx': 11, 'been': 9, 'does': 21, 'il': 41, 'years': 97, '2018': 0, 'help': 34, 'read': 65, 'was': 84, 'housing': 36, 'learning': 47, 'five': 27, 'first': 26, 'stacy': 70, 'di': 19, 'no': 53, 'mile': 50, 'urban': 81, 'they': 76, 'isn': 44, 'women': 94}
    

**TFIDF** - Term Frequency - Inverse Document Frequency is a numerical statistic that is intended to reflect how important a word is to a document in a collection or corpus. Gives more weight to rare words.

- some words are more important indicators of relevance than other because they are more rare


```python

from sklearn.feature_extraction.text import TfidfTransformer

tfidf = TfidfTransformer()
X_train_tfidf = tfidf.fit_transform(X_train_counts)
```


```python

```




    <200x100 sparse matrix of type '<class 'numpy.float64'>'
    	with 1913 stored elements in Compressed Sparse Row format>



## 4.3 Sentiment Analysis

**Sentiment Analysis** is the process of computationally identifying and categorizing opinions expressed in a piece of text, especially in order to determine whether the writer's attitude towards a particular topic, product, etc., is positive, negative, or neutral.

### 4.3.1 Classifying the tweets

We have already imported `textblob` and `re` in earlier steps to help us with the Sentiment Analysis. 

Let's create 2 functions to help us to clean the tweets and classify its polarity.

We'll create an additional column in our existing dataframe and add the tweet's polarity


```python
# create a column with the result of the functions created above
data['SA_tb'] = np.array([analyze_sentiment_tb(tweet) for tweet in data['Tweets']])
data['SA_vd'] = np.array([analyze_sentiment_vd(tweet) for tweet in data['Tweets']])

# display the first 10 tweets
display(data.head(10))
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Tweets</th>
      <th>ID</th>
      <th>source</th>
      <th>date</th>
      <th>lang</th>
      <th>len</th>
      <th>likes</th>
      <th>rts</th>
      <th>SA_tb</th>
      <th>SA_vd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ICYMI: “Examine the stability of the creek and...</td>
      <td>1023615412418879489</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-29 17:05:06</td>
      <td>en</td>
      <td>139</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ICYMI: The heart of the home also has a vital ...</td>
      <td>1023268125134008321</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-28 18:05:07</td>
      <td>en</td>
      <td>136</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Don’t miss the new season of Project Impossibl...</td>
      <td>1023236913539571713</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-28 16:01:05</td>
      <td>en</td>
      <td>140</td>
      <td>16</td>
      <td>9</td>
      <td>-1</td>
      <td>-1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Our #Denver office is excited to sponsor the i...</td>
      <td>1022859412099289088</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 15:01:02</td>
      <td>en</td>
      <td>140</td>
      <td>10</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Proud to be recognized as an industry leader o...</td>
      <td>1022844196061884416</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 14:00:34</td>
      <td>en</td>
      <td>140</td>
      <td>12</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>#Workhard &amp;amp; #playhard, dat doen onze young...</td>
      <td>1022777542279880704</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 09:35:43</td>
      <td>nl</td>
      <td>128</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Delighted to announce that Tim Williams has jo...</td>
      <td>1022774869002473472</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-27 09:25:05</td>
      <td>en</td>
      <td>144</td>
      <td>10</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>.@HISTORY is launching a new season of Project...</td>
      <td>1022497090969260032</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 15:01:18</td>
      <td>en</td>
      <td>140</td>
      <td>18</td>
      <td>5</td>
      <td>-1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>It’s amazing when a plan comes together. Our t...</td>
      <td>1022493959522865152</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 14:48:51</td>
      <td>en</td>
      <td>140</td>
      <td>3</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Our #SanFrancisco office is so grateful for th...</td>
      <td>1022485478770135041</td>
      <td>Hootsuite Inc.</td>
      <td>2018-07-26 14:15:09</td>
      <td>en</td>
      <td>127</td>
      <td>8</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


#### 4.3.2 Analyzing the results

**TextBlob** - The sentiment property returns a namedtuple of the form *Sentiment*(polarity, subjectivity). The polarity score is a float within the range [-1.0, 1.0]. The subjectivity is a float within the range [0.0, 1.0] where 0.0 is very objective and 1.0 is very subjective.


**Polarity** measures how positive or negative some texts is and **subjectivity** measures how much of an opinion it is versus how much factual.


```python
analysis_tb = TextBlob(tweet.text)
print(tweet.text, analysis_tb.sentiment)
```

    Proud to be recognized as an industry leader on @ENRnews Top 150 #Design Firms, a result of our continued growth an… https://t.co/jdwlb0rq4y Sentiment(polarity=0.65, subjectivity=0.75)
    

**VADER** - The **compound score** is computed by summing the valence scores of each word in the lexicon, adjusted according to the rules, and then normalized to be between -1 (most extreme negative) and +1 (most extreme positive). This is the most useful metric if you want a single unidimensional measure of sentiment for a given sentence. Calling it a 'normalized, weighted composite score' is accurate.


```python
analysis_vd = SentimentIntensityAnalyzer()
vd = analysis_vd.polarity_scores(tweet.text)
print(tweet.text,": ", vd)
```

    Proud to be recognized as an industry leader on @ENRnews Top 150 #Design Firms, a result of our continued growth an… https://t.co/jdwlb0rq4y :  {'neg': 0.0, 'neu': 0.706, 'pos': 0.294, 'compound': 0.7579}
    

***

Count the number of positive, negative, neutral tweets and extract the percentages.


```python
# extract the positive, negative and neutral tweets

# textBlob
pos_tweets_tb = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_tb'][index] > 0]
neu_tweets_tb = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_tb'][index] == 0]
neg_tweets_tb = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_tb'][index] < 0]
# vader
pos_tweets_vd = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_vd'][index] > 0]
neu_tweets_vd = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_vd'][index] == 0]
neg_tweets_vd = [ tweet for index, tweet in enumerate(data['Tweets']) if data['SA_vd'][index] < 0]
```


```python
# print the percentages
# textBlob
print("TextBlob - Perecentage of positive tweets: {}%".format(len(pos_tweets_tb)*100/len(data['Tweets'])))
print("TextBlob - Perecentage of neutral tweets: {}%".format(len(neu_tweets_tb)*100/len(data['Tweets']))) 
print("TextBlob - Perecentage of negative tweets: {}% \n".format(len(neg_tweets_tb)*100/len(data['Tweets'])))      
# vader
print("VADER - Perecentage of positive tweets: {}%".format(len(pos_tweets_vd)*100/len(data['Tweets'])))
print("VADER - Perecentage of neutral tweets: {}%".format(len(neu_tweets_vd)*100/len(data['Tweets']))) 
print("VADER - Perecentage of negative tweets: {}%".format(len(neg_tweets_vd)*100/len(data['Tweets'])))      
```

    TextBlob - Perecentage of positive tweets: 49.5%
    TextBlob - Perecentage of neutral tweets: 41.0%
    TextBlob - Perecentage of negative tweets: 9.5% 
    
    VADER - Perecentage of positive tweets: 56.5%
    VADER - Perecentage of neutral tweets: 36.0%
    VADER - Perecentage of negative tweets: 7.5%
    

## 4.5 Building our models

There are various algorithms which can be used for text classification

- **initial analysis**
 - grab top 100 words
 - top 10 words, univariate
 - subsetting postive or negative
 - what kind of similarties do they have?

- **exploratory data analysis**
 - top # of 2-words
 - bi-grams, n-grams, 2 or 3
 - n-grams, 


### Identify the evaluation measures: accuracy, precision, recall:


```python
# code here
```

## 5.0 Future Work & Next steps

- use the coordinates from the tweepy object to plot the tweets on a geographical map
- use neural network for modelling
- use other Natural Language toolkits like, SpaCY, Genism, Spark NLP

## 6.0 References

- Ali Hasan, S. M. (2018). Machine Learning-Based Sentiment Analysis for Twitter Accounts. Mathematical and Computational Applications.
- Ankit Pradeep Patel, A. V. (2017). Literature Survey on Sentiment Analysis of Twitter Data using Machine Learning Approaches. IJIRST –International Journal for Innovative Research in Science & Technology | Volume 3 | Issue 10.
- Hutto, C.J., Gilbert, Eric. (2017) VADER: A Parsimonious Rule-based Model for Sentiment Analysis of Social Media text
- Janani, D. S. (2016). Text Mining: Open Source Tokenization Tools - An Analysis. Advanced Computational Intelligence: An International Journal (ACII), Vol.3, No.1, January 2016. 
- Joachims, Y. Y. (2008). Text_categorization. Retrieved from Scholarpedia: http://www.scholarpedia.org/article/Text_categorization
- Kastrenakes, J. (2018, February 8). Twitter says people are tweeting more, but not longer, with 280-character limit. Retrieved from theverge: https://www.theverge.com/2018/2/8/16990308/twitter-280-character-tweet-length
- Katrekar, A. (n.d.). An Introduction to Sentiment Analysis. GlobalLogic.
- Sebastian, A. K. (2012). Sentiment Analysis on Twitter. International Journal of Computer Science Issues | Vol. 9 | Issue 4 | No. 3.


